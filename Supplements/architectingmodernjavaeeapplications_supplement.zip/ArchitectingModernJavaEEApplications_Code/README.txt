This code bundle contains the code examples for Architecting Modern Java EE Applications.

These examples match the code snippets shown in the book.They are aimed to give the readers an idea of the material.The examples can be viewed in an IDE and all build project examples can be compiled and packaged successfully.
However, not all examples are meant for deployment to an application server.This is due to the variations in the examples.The same reasoning caused comments put into JavaDoc and `package-info.java` files that explain the structure of these examples.These comments would not be part of an enterprise project.

Chapters 3 and 4 does not have any code files.

