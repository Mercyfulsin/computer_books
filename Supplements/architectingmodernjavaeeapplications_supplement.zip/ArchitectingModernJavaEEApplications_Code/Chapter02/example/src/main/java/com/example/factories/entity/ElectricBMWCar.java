package com.example.factories.entity;

import javax.enterprise.inject.Specializes;

@Specializes
public class ElectricBMWCar extends BMWCar {
}
