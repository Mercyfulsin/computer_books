package com.example.rdbms.cars.entity;

public enum EngineType {

    DIESEL, PETROL, ELECTRIC

}
