package com.example.async.jaxrs_client;

public class Forecast {

    private String forecast;

    public String getForecast() {
        return forecast;
    }

    public void setForecast(String forecast) {
        this.forecast = forecast;
    }

}
