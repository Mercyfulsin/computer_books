package com.example.factories.entity;

public enum EngineType {

    DIESEL, PETROL, ELECTRIC

}
