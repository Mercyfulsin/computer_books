package com.example.core_components.entity;

public enum EngineType {

    DIESEL, PETROL, ELECTRIC

}
