package com.example.http_client.entity;

public class CoffeeOrder {

    private OrderId id;

    public OrderId getId() {
        return id;
    }

}
