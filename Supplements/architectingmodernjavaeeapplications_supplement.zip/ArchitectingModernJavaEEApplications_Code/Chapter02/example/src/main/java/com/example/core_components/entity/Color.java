package com.example.core_components.entity;

public enum Color {

    BLACK, RED, GREY

}
