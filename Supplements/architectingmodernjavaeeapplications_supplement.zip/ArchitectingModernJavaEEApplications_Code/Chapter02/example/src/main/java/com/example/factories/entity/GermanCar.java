package com.example.factories.entity;

public interface GermanCar {
}
