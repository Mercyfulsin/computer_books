package com.example.async.jaxrs_resource;

public class UserStore {

    public long create(User user) {
        // ...
        return 1;
    }

}
