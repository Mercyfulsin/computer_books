package com.example.rdbms.cars.entity;

public enum SeatMaterial {

    VINYL, FAUX_LEATHER, LEATHER

}
