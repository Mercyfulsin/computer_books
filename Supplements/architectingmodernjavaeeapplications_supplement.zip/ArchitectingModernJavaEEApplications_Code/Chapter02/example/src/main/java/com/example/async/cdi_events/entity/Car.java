package com.example.async.cdi_events.entity;

public class Car {

    // ...

}
