package com.example.cdi_producers;

public class CarFactory {

    // ...

}
