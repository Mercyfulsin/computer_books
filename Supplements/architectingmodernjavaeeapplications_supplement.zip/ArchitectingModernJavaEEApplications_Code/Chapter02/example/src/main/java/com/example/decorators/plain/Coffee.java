package com.example.decorators.plain;

public interface Coffee {

    double getCaffeine();

    double getCalories();

}
