package com.example.cdi_events.entity;

public class Specification {

    // ...

}
