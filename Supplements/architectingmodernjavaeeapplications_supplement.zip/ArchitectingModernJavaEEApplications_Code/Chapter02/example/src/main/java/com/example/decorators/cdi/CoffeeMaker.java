package com.example.decorators.cdi;

public interface CoffeeMaker {

    void makeCoffee();

}
