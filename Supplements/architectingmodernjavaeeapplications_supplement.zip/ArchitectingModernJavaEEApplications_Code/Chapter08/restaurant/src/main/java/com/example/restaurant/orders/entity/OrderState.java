package com.example.restaurant.orders.entity;

public enum OrderState {

    PLACED, STARTED, DELIVERED, CANCELLED

}
