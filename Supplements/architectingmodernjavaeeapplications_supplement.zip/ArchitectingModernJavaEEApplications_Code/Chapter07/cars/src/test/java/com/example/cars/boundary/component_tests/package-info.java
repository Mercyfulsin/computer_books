/**
 * This package solely exists to avoid naming conflicts.
 * The component tests usually reside directly in the corresponding package,
 * that is {@link com.example.cars.boundary}.
 */
package com.example.cars.boundary.component_tests;