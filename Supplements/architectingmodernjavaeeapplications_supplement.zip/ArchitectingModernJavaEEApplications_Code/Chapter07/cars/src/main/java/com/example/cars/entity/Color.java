package com.example.cars.entity;

public enum Color {

    BLACK, RED, GREY

}
