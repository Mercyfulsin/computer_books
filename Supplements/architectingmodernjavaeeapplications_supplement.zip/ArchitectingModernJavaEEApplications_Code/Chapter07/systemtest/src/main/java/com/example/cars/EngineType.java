package com.example.cars;

public enum EngineType {

    DIESEL, PETROL, ELECTRIC

}
