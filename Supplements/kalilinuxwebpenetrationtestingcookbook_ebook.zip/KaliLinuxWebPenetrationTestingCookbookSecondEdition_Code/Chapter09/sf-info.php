<?
system('pwd');
system('ls');
?>