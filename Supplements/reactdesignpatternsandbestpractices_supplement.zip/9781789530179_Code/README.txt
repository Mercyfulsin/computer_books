All the chapters except chapters 1,2,13,14 contain code files
Chapter 2 has only syntaxes