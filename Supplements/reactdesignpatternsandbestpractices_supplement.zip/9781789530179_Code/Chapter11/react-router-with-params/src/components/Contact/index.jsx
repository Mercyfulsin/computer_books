import React from 'react';

const Contact = () => (
  <div className="Contact">
    <h1>Contact</h1>
  </div>
);

export default Contact;
