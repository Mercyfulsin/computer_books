import React from 'react';
import ShowInformation from './components/ShowInformation';

const App = () => <ShowInformation />;

export default App;
