import React, { Component } from 'react';
import Reset from './components/Reset'
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Reset />
      </div>
    );
  }
}

export default App;
