import React, { Component } from 'react';
import Transition from './components/Transition'
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Transition />
      </div>
    );
  }
}

export default App;
