import React, { Component } from 'react';
import Uncontrolled from './components/Uncontrolled'
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Uncontrolled />
      </div>
    );
  }
}

export default App;
