Create React app:
create-react-app weatherApp

Replace App.js file with the file from Github

Start your app:
npm start