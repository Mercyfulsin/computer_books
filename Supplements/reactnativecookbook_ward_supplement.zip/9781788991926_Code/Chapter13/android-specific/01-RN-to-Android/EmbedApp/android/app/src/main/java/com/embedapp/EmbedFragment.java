package com.embedapp;

import android.os.Bundle;

/**
 * Created by stan229 on 9/14/16.
 */
public class EmbedFragment extends ReactFragment {
    @Override
    public String getMainComponentName() {
        return "EmbedApp";
    }
}
