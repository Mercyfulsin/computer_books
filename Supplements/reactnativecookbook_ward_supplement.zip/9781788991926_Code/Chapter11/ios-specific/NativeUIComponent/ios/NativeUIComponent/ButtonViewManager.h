//
//  ButtonViewManager.h
//  NativeUIComponent
//
//  Created by Daniel Ward on 6/17/18.
//  Copyright © 2018 Facebook. All rights reserved.
//

#import "React/RCTViewManager.h"

@interface ButtonViewManager : RCTViewManager

@end
