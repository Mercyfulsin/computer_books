import React from 'react';
import { render } from 'react-dom';

import App from './App';

// Renders the main router, including the
// feature routes.
render(<App />, document.getElementById('root'));
