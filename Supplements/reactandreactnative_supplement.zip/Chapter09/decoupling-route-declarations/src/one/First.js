import React from 'react';

export default () => (
  <p>Feature 1, page 1</p>
);
