import fetchArticle from './fetchArticle';
import fetchArticles from './fetchArticles';

export { fetchArticle, fetchArticles };
